# siapa_test

Pest tests for the Rimba Who onboarding, recovery TOTP, password reset, and User-to-Staff person attribute transfer flows.

## Install location

Copy the contents of this archive into:

```text
vendor/rimba/who/tests
```

or into the package repository's `tests` directory before installing through Composer.

## Expected application assumptions

- `App\Models\User` has a factory.
- `User` uses `HasUserAuth` and `HasPersonAttributes`.
- `Staff` uses `HasPersonAttributes`.
- `ResetPassword` is a `SimplePage` with a `data` state path and password/password_confirmation fields.
- `SetupTwoFactor` uses `totp_secret`.
- `RequestPasswordReset::resolveUserAuth()` uses `$builder`, not an undefined `$query`.
- Package migrations are available to the test application.

## Run

```bash
php artisan optimize:clear
php artisan test vendor/rimba/who/tests
```

From the package repository with Testbench/Pest configured:

```bash
vendor/bin/pest
```

## Covered scenarios

- TOTP secret generation and preservation
- Valid and invalid TOTP setup
- Local password recovery by email and username
- Unknown user and missing-TOTP rejection
- LDAP recovery rejection
- Valid, invalid, expired, and tampered TOTP recovery sessions
- Valid local password reset
- Unverified, expired, tampered, and LDAP reset rejection
- Password confirmation validation
- Authentication-attempt audit records
- User-to-Staff attribute transfer and conflict precedence
- Encryption of the stored TOTP secret
