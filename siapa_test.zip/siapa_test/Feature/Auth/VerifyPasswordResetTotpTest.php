<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Livewire\Livewire;
use PragmaRX\Google2FA\Google2FA;
use Rimba\Who\Http\UI\Auth\VerifyPasswordResetTotp;
use Rimba\Who\Models\UserAuth;

uses(RefreshDatabase::class);

function verificationSession(UserAuth $auth, string $token): array
{
    return [
        'siapa.password_reset.user_auth_id' => $auth->id,
        'siapa.password_reset.verification_token_hash' => hash('sha256', $token),
        'siapa.password_reset.expires_at' => now()->addMinutes(10)->timestamp,
        'siapa.password_reset.totp_verified' => false,
    ];
}

it('verifies a valid recovery totp', function (): void {
    $user = User::factory()->create();
    $secret = app(Google2FA::class)->generateSecretKey();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'local-user',
        'totp_secret' => $secret,
        'setup_completed' => true,
    ]);
    $token = Str::random(64);
    $this->withSession(verificationSession($auth, $token));

    Livewire::test(VerifyPasswordResetTotp::class, ['token' => $token])
        ->set('data.code', app(Google2FA::class)->getCurrentOtp($secret))
        ->call('verify')
        ->assertSessionHas('siapa.password_reset.totp_verified', true)
        ->assertSessionHas('siapa.password_reset.reset_token_hash');

    $this->assertDatabaseHas('authentication_attempts', [
        'user_id' => $user->id,
        'event' => 'password_reset_totp',
        'success' => true,
    ]);
});

it('rejects an invalid recovery totp and logs it', function (): void {
    $user = User::factory()->create();
    $secret = app(Google2FA::class)->generateSecretKey();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'bad-code-user',
        'totp_secret' => $secret,
        'setup_completed' => true,
    ]);
    $token = Str::random(64);
    $this->withSession(verificationSession($auth, $token));

    Livewire::test(VerifyPasswordResetTotp::class, ['token' => $token])
        ->set('data.code', '000000')
        ->call('verify')
        ->assertHasErrors(['data.code']);

    $this->assertDatabaseHas('authentication_attempts', [
        'user_id' => $user->id,
        'event' => 'password_reset_totp',
        'success' => false,
    ]);
});

it('rejects tampered and expired verification sessions', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'token-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);
    $token = Str::random(64);

    $this->withSession(verificationSession($auth, $token));
    Livewire::test(VerifyPasswordResetTotp::class, ['token' => 'tampered'])->assertForbidden();

    $expired = verificationSession($auth, $token);
    $expired['siapa.password_reset.expires_at'] = now()->subMinute()->timestamp;
    $this->withSession($expired);
    Livewire::test(VerifyPasswordResetTotp::class, ['token' => $token])->assertForbidden();
});

it('rejects an ldap recovery session', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'ldap',
        'auth_identifier' => 'ldap-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);
    $token = Str::random(64);
    $this->withSession(verificationSession($auth, $token));

    Livewire::test(VerifyPasswordResetTotp::class, ['token' => $token])->assertForbidden();
});
