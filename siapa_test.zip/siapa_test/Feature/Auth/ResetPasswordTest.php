<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Livewire\Livewire;
use Rimba\Who\Http\UI\Auth\ResetPassword;
use Rimba\Who\Models\UserAuth;

uses(RefreshDatabase::class);

function resetSession(UserAuth $auth, string $token): array
{
    return [
        'siapa.password_reset.user_auth_id' => $auth->id,
        'siapa.password_reset.reset_token_hash' => hash('sha256', $token),
        'siapa.password_reset.expires_at' => now()->addMinutes(10)->timestamp,
        'siapa.password_reset.totp_verified' => true,
    ];
}

it('resets a local password after totp verification', function (): void {
    $user = User::factory()->create(['password' => Hash::make('OldPassword123!')]);
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'local-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);
    $token = Str::random(64);
    $this->withSession(resetSession($auth, $token));

    Livewire::test(ResetPassword::class, ['token' => $token])
        ->set('data.password', 'NewPassword123!')
        ->set('data.password_confirmation', 'NewPassword123!')
        ->call('resetPassword');

    expect(Hash::check('NewPassword123!', $user->fresh()->password))->toBeTrue()
        ->and(session()->has('siapa.password_reset.user_auth_id'))->toBeFalse();

    $this->assertDatabaseHas('authentication_attempts', [
        'user_id' => $user->id,
        'event' => 'password_reset',
        'success' => true,
    ]);
});

it('rejects unverified expired tampered and ldap reset attempts', function (): void {
    $user = User::factory()->create(['password' => Hash::make('OriginalPassword123!')]);
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'guarded-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);
    $token = Str::random(64);

    $unverified = resetSession($auth, $token);
    $unverified['siapa.password_reset.totp_verified'] = false;
    $this->withSession($unverified);
    Livewire::test(ResetPassword::class, ['token' => $token])->assertForbidden();

    $expired = resetSession($auth, $token);
    $expired['siapa.password_reset.expires_at'] = now()->subMinute()->timestamp;
    $this->withSession($expired);
    Livewire::test(ResetPassword::class, ['token' => $token])->assertForbidden();

    $this->withSession(resetSession($auth, $token));
    Livewire::test(ResetPassword::class, ['token' => 'tampered'])->assertForbidden();

    $auth->update(['auth_provider' => 'ldap']);
    $this->withSession(resetSession($auth->fresh(), $token));
    Livewire::test(ResetPassword::class, ['token' => $token])->assertForbidden();

    expect(Hash::check('OriginalPassword123!', $user->fresh()->password))->toBeTrue();
});

it('validates password confirmation', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'confirmation-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);
    $token = Str::random(64);
    $this->withSession(resetSession($auth, $token));

    Livewire::test(ResetPassword::class, ['token' => $token])
        ->set('data.password', 'NewPassword123!')
        ->set('data.password_confirmation', 'DifferentPassword123!')
        ->call('resetPassword')
        ->assertHasErrors(['data.password']);
});
