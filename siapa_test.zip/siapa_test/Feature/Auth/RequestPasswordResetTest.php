<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Rimba\Who\Http\UI\Auth\RequestPasswordReset;
use Rimba\Who\Models\UserAuth;

uses(RefreshDatabase::class);

it('starts recovery for a local account with totp by email', function (): void {
    $user = User::factory()->create(['email' => 'local@example.test']);
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'local-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);

    Livewire::test(RequestPasswordReset::class)
        ->set('data.email', 'local@example.test')
        ->call('request')
        ->assertSessionHas('siapa.password_reset.user_auth_id', $auth->id)
        ->assertSessionHas('siapa.password_reset.verification_token_hash')
        ->assertSessionHas('siapa.password_reset.expires_at')
        ->assertSessionHas('siapa.password_reset.totp_verified', false);
});

it('starts recovery for a local account by username', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'ahmad',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);

    Livewire::test(RequestPasswordReset::class)
        ->set('data.email', 'ahmad')
        ->call('request')
        ->assertSessionHas('siapa.password_reset.user_auth_id', $auth->id);
});

it('blocks ldap password recovery', function (): void {
    $user = User::factory()->create(['email' => 'ldap@example.test']);
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'ldap',
        'auth_identifier' => 'ldap-user',
        'setup_completed' => true,
    ]);

    Livewire::test(RequestPasswordReset::class)
        ->set('data.email', 'ldap@example.test')
        ->call('request')
        ->assertNotified();

    expect(session()->has('siapa.password_reset.user_auth_id'))->toBeFalse();
});

it('rejects a local account without recovery totp', function (): void {
    $user = User::factory()->create(['email' => 'nototp@example.test']);
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'no-totp',
        'totp_secret' => null,
        'setup_completed' => true,
    ]);

    Livewire::test(RequestPasswordReset::class)
        ->set('data.email', 'nototp@example.test')
        ->call('request')
        ->assertHasErrors(['data.email']);
});

it('rejects an unknown account', function (): void {
    Livewire::test(RequestPasswordReset::class)
        ->set('data.email', 'missing@example.test')
        ->call('request')
        ->assertHasErrors(['data.email']);
});
