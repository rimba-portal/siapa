<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PragmaRX\Google2FA\Google2FA;
use Rimba\Who\Http\UI\Auth\SetupTwoFactor;
use Rimba\Who\Models\UserAuth;

uses(RefreshDatabase::class);

it('generates a recovery totp secret when none exists', function (): void {
    $user = User::factory()->create();
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'new-user',
        'totp_secret' => null,
        'setup_completed' => false,
    ]);

    $this->actingAs($user);
    Livewire::test(SetupTwoFactor::class);

    expect($user->userAuth->fresh()->totp_secret)->not->toBeNull()->not->toBe('');
});

it('does not regenerate an existing totp secret', function (): void {
    $user = User::factory()->create();
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'existing-user',
        'totp_secret' => 'EXISTING-SECRET',
        'setup_completed' => false,
    ]);

    $this->actingAs($user);
    Livewire::test(SetupTwoFactor::class);

    expect($user->userAuth->fresh()->totp_secret)->toBe('EXISTING-SECRET');
});

it('accepts a valid authenticator code', function (): void {
    $user = User::factory()->create();
    $secret = app(Google2FA::class)->generateSecretKey();
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'valid-user',
        'totp_secret' => $secret,
        'setup_completed' => false,
    ]);

    $this->actingAs($user);
    Livewire::test(SetupTwoFactor::class)
        ->set('data.code', app(Google2FA::class)->getCurrentOtp($secret))
        ->call('confirm');

    expect($user->userAuth->fresh()->setup_completed)->toBeTrue();
});

it('rejects an invalid authenticator code', function (): void {
    $user = User::factory()->create();
    $secret = app(Google2FA::class)->generateSecretKey();
    UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'invalid-user',
        'totp_secret' => $secret,
        'setup_completed' => false,
    ]);

    $this->actingAs($user);
    Livewire::test(SetupTwoFactor::class)
        ->set('data.code', '000000')
        ->call('confirm')
        ->assertStatus(422);

    expect($user->userAuth->fresh()->setup_completed)->toBeFalse();
});
