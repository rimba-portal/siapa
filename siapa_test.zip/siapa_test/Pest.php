<?php

declare(strict_types=1);

use Rimba\Who\Tests\TestCase;

uses(TestCase::class)->in('Feature', 'Unit');
