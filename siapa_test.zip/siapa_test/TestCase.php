<?php

declare(strict_types=1);

namespace Rimba\Who\Tests;

use Orchestra\Testbench\TestCase as Orchestra;
use Rimba\Attributing\AttributingServiceProvider;
use Rimba\People\PeopleServiceProvider;
use Rimba\Who\WhoServiceProvider;

abstract class TestCase extends Orchestra
{
    protected function getPackageProviders($app): array
    {
        return [
            AttributingServiceProvider::class,
            PeopleServiceProvider::class,
            WhoServiceProvider::class,
        ];
    }

    protected function defineEnvironment($app): void
    {
        $app['config']->set('auth.providers.users.model', \App\Models\User::class);
        $app['config']->set('bites_auth.staff_model', \Rimba\People\Models\Staff::class);
        $app['config']->set('bites_auth.staff_number_column', 'staff_no');
        $app['config']->set('bites_auth.staff_user_column', 'user_id');
    }
}
