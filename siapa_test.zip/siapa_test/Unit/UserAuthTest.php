<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Rimba\Who\Enums\SecurityLevel;
use Rimba\Who\Models\UserAuth;

uses(RefreshDatabase::class);

it('reports whether recovery totp is configured', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'local-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => false,
    ]);

    expect($auth->hasTotp())->toBeTrue();

    $auth->update(['totp_secret' => null]);
    expect($auth->fresh()->hasTotp())->toBeFalse();
});

it('encrypts the totp secret in storage', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'encrypted-user',
        'totp_secret' => 'MY-PLAIN-SECRET',
        'setup_completed' => false,
    ]);

    $raw = DB::table('user_auths')->where('id', $auth->id)->value('totp_secret');

    expect($raw)->not->toBe('MY-PLAIN-SECRET')
        ->and($auth->fresh()->totp_secret)->toBe('MY-PLAIN-SECRET');
});

it('marks setup completed and incomplete', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'setup-user',
        'setup_completed' => false,
    ]);

    $auth->markSetupCompleted();
    expect($auth->fresh()->setup_completed)->toBeTrue();

    $auth->markSetupIncomplete();
    expect($auth->fresh()->setup_completed)->toBeFalse();
});

it('does not use recovery totp as a panel security level', function (): void {
    $user = User::factory()->create();
    $auth = UserAuth::query()->create([
        'user_id' => $user->id,
        'auth_provider' => 'local',
        'auth_identifier' => 'security-user',
        'totp_secret' => 'SECRET123',
        'setup_completed' => true,
    ]);

    $this->actingAs($user);
    expect($auth->securityLevel())->toBe(SecurityLevel::Authenticated);
});
