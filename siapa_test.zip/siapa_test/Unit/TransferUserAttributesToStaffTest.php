<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Rimba\Attributing\Models\AttributeDefinition;
use Rimba\People\Models\Staff;
use Rimba\Who\Actions\TransferUserAttributesToStaff;

uses(RefreshDatabase::class);

beforeEach(function (): void {
    foreach (['phone', 'preferred_language'] as $key) {
        AttributeDefinition::query()->create([
            'family' => 'person',
            'group' => 'identity',
            'key' => $key,
            'name' => ucfirst(str_replace('_', ' ', $key)),
            'applies_to' => ['staff'],
            'is_active' => true,
        ]);
    }
});

function staffFor(User $user, string $number): Staff
{
    return Staff::query()->create([
        'user_id' => $user->id,
        'name' => $user->name,
        'staff_no' => $number,
        'type' => 'FTE',
        'status' => 'active',
    ]);
}

it('moves a user person attribute to staff while preserving the row', function (): void {
    $user = User::factory()->create();
    $staff = staffFor($user, '100001');
    $attribute = $user->personAttributes()->create(['key' => 'phone', 'value' => '0123456789']);

    app(TransferUserAttributesToStaff::class)->handle($user, $staff);
    $attribute->refresh();

    expect($attribute->attributable_id)->toBe($staff->id)
        ->and($attribute->attributable_type)->toBe($staff->getMorphClass());
});

it('preserves a non-empty staff value', function (): void {
    $user = User::factory()->create();
    $staff = staffFor($user, '100002');
    $user->personAttributes()->create(['key' => 'phone', 'value' => 'USER-VALUE']);
    $staff->personAttributes()->create(['key' => 'phone', 'value' => 'HR-VALUE']);

    app(TransferUserAttributesToStaff::class)->handle($user, $staff);

    expect($staff->personAttributes()->where('key', 'phone')->value('value'))->toBe('HR-VALUE')
        ->and($user->personAttributes()->where('key', 'phone')->exists())->toBeFalse();
});

it('fills a blank staff value from user onboarding', function (): void {
    $user = User::factory()->create();
    $staff = staffFor($user, '100003');
    $user->personAttributes()->create(['key' => 'phone', 'value' => 'USER-VALUE']);
    $staff->personAttributes()->create(['key' => 'phone', 'value' => null]);

    app(TransferUserAttributesToStaff::class)->handle($user, $staff);

    expect($staff->personAttributes()->where('key', 'phone')->value('value'))->toBe('USER-VALUE');
});

it('keeps application preference attributes on user', function (): void {
    $user = User::factory()->create();
    $staff = staffFor($user, '100004');
    $user->personAttributes()->create(['key' => 'preferred_language', 'value' => 'en']);

    app(TransferUserAttributesToStaff::class)->handle($user, $staff);

    expect($user->personAttributes()->where('key', 'preferred_language')->exists())->toBeTrue()
        ->and($staff->personAttributes()->where('key', 'preferred_language')->exists())->toBeFalse();
});
